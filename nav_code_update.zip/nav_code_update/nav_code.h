#ifndef NAV_CODE_NAV_CODE_H
#define NAV_CODE_NAV_CODE_H

#include "Arduino.h"

/*
* DISCLAIMER: We used GPT-4 to generate the code that the distance sensor uses to read distance (getDistance)
*/

const double NORTH = M_PI/2;
const double SOUTH = -(double)M_PI/2;
const double EAST = 0;
const double WEST = M_PI;
const double MARGIN = M_PI/50;

// pins for the distance sensors (PWM)

// left
const int TRIGGER_1 = 2;
const int ECHO_1 = 3;

// right
const int TRIGGER_2 = 4;
const int ECHO_2 = 5;

// pins for motor control (PWM)

// left motor
const int EN_A = 8;
const int IN_1 = 9;
const int IN_2 = 10;

// right motor
const int EN_B = 13;
const int IN_3 = 11;
const int IN_4 = 12;

// Functions
double getX();
double getY();
double getHeading();
void setMotorSpeed(int PWMspeed);
void setMotorDir(int motor, bool forward);
void rotateRight(int PWMspeed);
void rotateLeft(int PWMspeed);
void faceDir(double limit);
void moveToLocation(bool xDir, double limit);
void moveX(double limit);
void moveY(double limit);
int getDistance(int trigger_pin, int echo_pin);

#endif //NAV_CODE_NAV_CODE_H
