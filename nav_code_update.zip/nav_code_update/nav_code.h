#ifndef NAV_CODE_NAV_CODE_H
#define NAV_CODE_NAV_CODE_H

#include "Arduino.h"
#include <Servo.h>

/*
* DISCLAIMER: We used GPT-4 to generate the code that the distance sensor uses to read distance (getDistance)
*/

const double NORTH = M_PI/2;
const double SOUTH = -M_PI/2;
const double EAST = 0;
const double WEST = M_PI;
const double MARGIN = M_PI/50;

// pins for the distance sensors (PWM)

// left
const int TRIGGER_1 = 2;
const int ECHO_1 = 3;

// right
const int TRIGGER_2 = 4;
const int ECHO_2 = 5;

// pins for motor control (PWM)

// left motor
const int EN_A = 8;
const int IN_1 = 9;
const int IN_2 = 10;

// right motor
const int EN_B = 13;
const int IN_3 = 11;
const int IN_4 = 12;

// Topology sensors
const int sensorPinLeft = 30;
const int sensorPinRight = 31;

// Flame sensors
const int analogPinIR1 = A0;
const int analogPinIR2 = A1;
const int analogPinIR3 = A2;
const int analogPinIR4 = A3;

// Functions
void missionStart(int arucoID, int tx, int rx);
void updateLocation();
double getX();
double getY();
double getHeading();
double getYMissionLocation();
void setMotorSpeed(int PWMspeed);
void setMotorDir(int motor, bool forward);
void rotateRight(int PWMspeed);
void rotateLeft(int PWMspeed);
void faceDir(double limit);
void moveToLocation(bool xDir, double limit);
void moveX(double limit);
void moveY(double limit);
int getDistance(int trigger_pin, int echo_pin); 
void reportTop(int top);
void reportFlames(int flames);

#endif //NAV_CODE_NAV_CODE_H
