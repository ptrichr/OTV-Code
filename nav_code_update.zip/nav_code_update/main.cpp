#include "Arduino.h"
#include "nav_code.h"
#include "Enes100.h"
#include <math.h>

void missionStart(int arucoID, int tx, int rx) {

    Enes100.begin("Trial by Fire", FIRE, arucoID, tx, rx);

}

void updateLocation() {

    Enes100.updateLocation();

}

double getX() {

  Enes100.updateLocation();

  return Enes100.location.x;

}

double getY() {

  Enes100.updateLocation();

  return Enes100.location.y;

}

double getHeading() {

  Enes100.updateLocation();

  return Enes100.location.theta;

}

double getYMissionLocation() {

    return Enes100.missionSite.y;

}

void setMotorSpeed(int PWMspeed) {

  
  if (PWMspeed == 0) {

    digitalWrite(EN_A, LOW);
    digitalWrite(EN_B, LOW);
    return;

  }

  analogWrite(EN_A, PWMspeed);
  analogWrite(EN_B, PWMspeed);

}

void setMotorDir(int motor, bool forward) {

  // left motor
  if (motor == 1) {

    if (forward) {

      digitalWrite(IN_1, LOW);
      digitalWrite(IN_2, HIGH);

    } else {

      digitalWrite(IN_1, HIGH);
      digitalWrite(IN_2, LOW);

    }

  // right motor
  } if (motor == 2) {

    if (forward) {

      digitalWrite(IN_3, LOW);
      digitalWrite(IN_4, HIGH);

    } else {

      digitalWrite(IN_3, HIGH);
      digitalWrite(IN_4, LOW);

    }
    
  }

}

void rotateRight(int PWMspeed) {

  setMotorDir(1, true);
  setMotorDir(2, false);
  setMotorSpeed(PWMspeed);

}

void rotateLeft(int PWMspeed) {

  setMotorDir(1, false);
  setMotorDir(2, true);
  setMotorSpeed(PWMspeed);

}

void faceDir(double limit) {

    Serial.print("faceDir: ");
    Serial.println(limit);

    Enes100.updateLocation();
  
    do {

        rotateLeft(100);
        // delay(100);
        // setMotorSpeed(0);
        
    } while (getHeading() < limit - MARGIN || getHeading() > limit + MARGIN);

    setMotorSpeed(0);
	
}

void moveToLocation(bool xDir, double limit) {

  Enes100.updateLocation();
	
	if (xDir) {
		
		moveX(limit);	
		
	} else {
		
		moveY(limit);
		
	}
	
}

void moveX(double limit) {
	
	do {
		
		setMotorSpeed(90);
        // delay(200);
        // setMotorSpeed(0);
		
	} while (getX() > limit + MARGIN || getX() < limit - MARGIN);

  setMotorSpeed(0);
	
}
	
void moveY(double limit) {
	
	do {
		
		setMotorSpeed(90);
        // delay(200);
        // setMotorSpeed(0);
		
	} while (getY() > limit + MARGIN || getY() < limit - MARGIN);

  setMotorSpeed(0);
	
}

int getDistance(int trigger_pin, int echo_pin) {

  // Send ultrasonic pulse
  digitalWrite(trigger_pin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigger_pin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigger_pin, LOW);

  // Receive echo and calculate distance in cm
  long duration = pulseIn(echo_pin, HIGH);
  int distance = (duration * 0.0343) / 2;
  return distance;

}

void reportTop(int top) {

    if (top == 1) {

        Enes100.mission(TOPOGRAPHY, TOP_A);

    }

    if (top == 2) {

        Enes100.mission(TOPOGRAPHY, TOP_B);

    }

    if (top == 3) {

        Enes100.mission(TOPOGRAPHY, TOP_C);

    }

}

void reportFlames(int flames) {

    Enes100.mission(NUM_CANDLES, flames);

}