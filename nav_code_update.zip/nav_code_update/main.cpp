#include "Arduino.h"
#include "nav_code.h"
#include "Enes100.h"
#include <math.h>

double getX() {

  Enes100.updateLocation();

  return Enes100.location.x;

}

double getY() {

  Enes100.updateLocation();

  return Enes100.location.y;

}

double getHeading() {

  Enes100.updateLocation();

  return Enes100.location.theta;

}

void setMotorSpeed(int PWMspeed) {

  
  if (PWMspeed == 0) {

    digitalWrite(EN_A, LOW);
    digitalWrite(EN_B, LOW);
    return;

  }

  analogWrite(EN_A, PWMspeed);
  analogWrite(EN_B, PWMspeed);

}

void setMotorDir(int motor, bool forward) {

  // left motor
  if (motor == 1) {

    if (forward) {

      digitalWrite(IN_1, LOW);
      digitalWrite(IN_2, HIGH);

    } else {

      digitalWrite(IN_1, HIGH);
      digitalWrite(IN_2, LOW);

    }

  // right motor
  } if (motor == 2) {

    if (forward) {

      digitalWrite(IN_3, LOW);
      digitalWrite(IN_4, HIGH);

    } else {

      digitalWrite(IN_3, HIGH);
      digitalWrite(IN_4, LOW);

    }
    
  }

}

void rotateRight(int PWMspeed) {

  setMotorDir(1, true);
  setMotorDir(2, false);
  setMotorSpeed(PWMspeed);

}

void rotateLeft(int PWMspeed) {

  setMotorDir(1, false);
  setMotorDir(2, true);
  setMotorSpeed(PWMspeed);

}

void faceDir(double limit) {

  Serial.print("faceDir: ");
  Serial.println(limit);

  Enes100.updateLocation();
  
	do {

    Enes100.println(getHeading());
    Serial.print("getheading(): ");
    Serial.println(getHeading());
	
		if ((getHeading() < limit - MARGIN) || (getHeading() > limit + MARGIN)) {
	
			rotateLeft(120);
      Enes100.println("here1");
      Serial.print("limit1: ");
      Serial.println(limit);
		
		}
	
		// if (getHeading() > limit + MARGIN) {
		
		// 	rotateRight(120);
    //   Enes100.println("here2");
    //   Serial.print("limit2: ");
    //   Serial.println(limit);
		
		// }

    delay(100);
    setMotorSpeed(0);

		
	} while ((getHeading() <= limit + MARGIN) && (getHeading() >= limit - MARGIN));

  setMotorSpeed(0);
  Enes100.println("here0");
  Serial.print("limit0: ");
  Serial.println(limit);

	
}

void moveToLocation(bool xDir, double limit) {

  Enes100.updateLocation()
	
	if (xDir) {
		
		moveX(limit);	
		
	} else {
		
		moveY(limit);
		
	}
	
}

void moveX(double limit) {
	
	do {

    if (getX() > limit + MARGIN) {

      setMotorDir(1, false);
      setMotorDir(2, false);

    }

    if (getX() < limit - MARGIN) {

      setMotorDir(1, true);
      setMotorDir(2, true);

    }
		
		setMotorSpeed(90);
		
	} while ((getX() <= limit + MARGIN) && (getX() >= limit - MARGIN));

  setMotorSpeed(0);
	
}
	
void moveY(double limit) {
	
	do {
		
    if (getY() > limit + MARGIN) {

      setMotorDir(1, false);
      setMotorDir(2, false);

    }

    if (getY() < limit - MARGIN) {

      setMotorDir(1, true);
      setMotorDir(2, true);

    }
		
		setMotorSpeed(90);
		
	} while ((getY() <= limit + MARGIN && getY() >= limit - MARGIN));

  setMotorSpeed(0);
	
}

int getDistance(int trigger_pin, int echo_pin) {

  // Send ultrasonic pulse
  digitalWrite(trigger_pin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigger_pin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigger_pin, LOW);

  // Receive echo and calculate distance in cm
  long duration = pulseIn(echo_pin, HIGH);
  int distance = (duration * 0.0343) / 2;
  return distance;

}