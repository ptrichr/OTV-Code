#include "Enes100.h"
#include "Arduino.h"
#include "nav_code.h"
#include <cmath>

/* This is an example function to make both motors drive
 * at the given power.
 */
void setMotorSpeed(int PWMspeed) {


    if (PWMspeed == 0) {

        digitalWrite(EN_A, LOW);
        digitalWrite(EN_B, LOW);
        return;

    }

    analogWrite(EN_A, PWMspeed);
    analogWrite(EN_B, PWMspeed);

}

void setMotorDir(int motor, bool forward) {


    // left motor
    if (motor == 1) {

        if (forward) {

            digitalWrite(IN_1, LOW);
            digitalWrite(IN_2, HIGH);

        } else {

            digitalWrite(IN_1, HIGH);
            digitalWrite(IN_2, LOW);

        }

        // right motor
    } if (motor == 2) {

        if (forward) {

            digitalWrite(IN_3, LOW);
            digitalWrite(IN_4, HIGH);

        } else {

            digitalWrite(IN_3, HIGH);
            digitalWrite(IN_4, LOW);

        }

    }

}

void rotateRight(int PWMspeed) {

    setMotorDir(1, true);
    setMotorDir(2, false);
    setMotorSpeed(PWMspeed);

}

void rotateLeft(int PWMspeed) {

    setMotorDir(1, false);
    setMotorDir(2, true);
    setMotorSpeed(PWMspeed);

}

void faceDir(double limit) {

    bool oriented = false;

    do {

        Enes100.updateLocation();

        if (Enes100.location.theta <= limit + MARGIN && Enes100.location.theta >= limit - MARGIN) {

            setMotorSpeed(0);
            oriented = true;

        }

        if (Enes100.location.theta < limit - MARGIN) {

            rotateLeft(90);

        }

        if (Enes100.location.theta > limit + MARGIN) {

            rotateRight(90);

        }

    } while (!oriented);

}

void moveToLocation(bool xDir, double limit) {

    setMotorDir(1, true);
    setMotorDir(2, true);

    if (xDir) {

        moveX(limit);

    } else {

        moveY(limit);

    }

}

void moveX(double limit) {

    bool done = false;

    do {

        Enes100.updateLocation();

        if (Enes100.location.x <= limit + MARGIN && Enes100.location.x >= limit - MARGIN) {

            setMotorSpeed(0);
            done = true;
            return;

        }

        setMotorSpeed(90);

    } while (!done);

}

void moveY(double limit) {

    bool done = false;

    do {

        Enes100.updateLocation();

        if (Enes100.location.y <= limit + MARGIN && Enes100.location.y >= limit - MARGIN) {

            setMotorSpeed(0);
            done = true;
            return;

        }

        setMotorSpeed(90);

    } while (!done);

}

int getDistance(int trigger_pin, int echo_pin) {

    // Send ultrasonic pulse
    digitalWrite(trigger_pin, LOW);
    delayMicroseconds(2);
    digitalWrite(trigger_pin, HIGH);
    delayMicroseconds(10);
    digitalWrite(trigger_pin, LOW);

    // Receive echo and calculate distance in cm
    long duration = pulseIn(echo_pin, HIGH);
    int distance = (duration * 0.0343) / 2;
    return distance;

}